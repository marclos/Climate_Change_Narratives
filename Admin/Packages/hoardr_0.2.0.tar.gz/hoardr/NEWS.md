hoardr 0.2.0
============

### CHANGES

* Compliance with CRAN policies about writing to users disk (#6)

### MINOR IMPROVEMENTS

* Improved documentation (#7)

### BUG FIXES

* Change `key()` and `keys()` to use `file=TRUE` (#8)
* Fix R6 import warning (#5)


hoardr 0.1.0
============

### NEW FEATURES

* released to CRAN
